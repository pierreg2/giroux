
<footer id="footer">
	<div class="inter">
				<a href="../elements/footerinfo.html">A propos</a>
				<a href="../elements/footerinfo.html">Politiques de confidentialité</a>
        		<a href="../elements/footerinfo.html">CGU</a>
                <a href="../elements/footerinfo.html">Accessibilité</a>

    </div>
</footer>
