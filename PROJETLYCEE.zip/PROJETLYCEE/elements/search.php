<?php
$servername = "localhost";
$username = "root";
$password ="root";
$database ="projet";

$connexion=mysqli_connect($servername,$username,$password,$database);

?>
<?php
session_start();
?>

<!DOCTYPE html>
<html >
 <head >
   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
   <link rel="stylesheet" href="../styles/styleformulaire.css" type="text/css" />

   <title>RECHERCHE</title>
   <h4> Vos résultats de recherche</h4>

 </head>



   <div id="menuArea">
   <?php require '../elements/menu.php'; ?>
   </div>

<body>

<center><div id="container1">
  <?php
if(isset($_POST['recherchebouton']) && !empty($_POST['recherche'])){//si on recoit une valeur du champ de recherche ou aucune valeur
    $recherche = mysqli_real_escape_string($connexion, $_POST['recherche']); //connexion a la bd
    //recupere les villes, departements ou lycees qui ont un champ qui ressemble au mot recherché

    $sql = "select * from communes,lycees,departement where communes.Code_commune = lycees.code_commune and departement.NumeroDep = communes.Code_departement
    and (etablissement like '%$recherche%' or academie like '%$recherche%' or communes.ville like '%$recherche%' or Département like '%$recherche%' or departement.NumeroDep like '%$recherche%')";


    $resultat = mysqli_query($connexion,$sql);
    $queryResultat = mysqli_num_rows($resultat);


    if($queryResultat >0){//si recupere des resultats
        while($row = mysqli_fetch_assoc($resultat)){//on les affiche tous

              echo"<div id=divider></div>";

              echo   "<a href='../option/lycee.php?l=".$row['code_etablissement']."'>".$row['etablissement']."</a>

                    <p>Ce lycée se trouve dans le département numéro ".$row['NumeroDep']." ".$row['Département']."  </p>";
              echo"<div id=divider></div>";
        }

    }else{//sinon affiche resultat introuvable
      echo " Résultat introuvable";
    }
}
else{//sinon affiche aucune valeur saisie
  echo "Aucune valeur saisie !";
}
 ?>

</div>

</center>


</body>
 </html>
