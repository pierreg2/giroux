<?php
  $servername = "localhost";
  $username = "root";
  $password ="root";
  $database ="projet";

  $connexion=mysqli_connect($servername,$username,$password,$database);
?>

<!DOCTYPE html>
<html>
   <head>
   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

   <link rel="stylesheet" href="../elements/styleformulaire.css" type="text/css" />

      <title>BARRE DE RECHERCHE</title>
      <body >

		<div class="form-style-10">
        <div class="inner-wrap">
        <form method="POST" action="search.php">
            <input type="search" name="recherche" placeholder="Tapez votre recherche…" value="" />
            <input type="submit" name="recherchebouton" value="Rechercher" />
        </form>
    </div>
  </div>

</body>
</head>
</html>
