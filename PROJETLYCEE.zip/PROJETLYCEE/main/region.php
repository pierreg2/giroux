<?php
session_start();
?>

<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" href="../styles/styleformulaire.css" type="text/css" media="screen" />
<title> Region </title>
<h4> Région </h4>
</head>

<body>

  <div id="menuArea">
  <?php require '../elements/menu.php'; ?>
  </div>

<div id="container1">

<p class='Region'>

<?php

 INCLUDE('../main/bd.php');
 $bdd=getBD();
 $codeR = $_GET['r'];
 $repR = $bdd->query("SELECT * FROM `region` WHERE Code_Region='$codeR'");
 $region = $repR->fetch();
 $nomR = $region['Nom_Region'];

 echo "<h4>".$nomR."</h4>";
 echo "<center><p>Départements de la région :</p></center>";
 echo "<table class=tableauregion>";
 $repD = $bdd->query("SELECT * FROM `departement` WHERE Code_Région='$codeR'"); #selection departement dans la region passee en GET
 while($dep = $repD->fetch()){

	 echo '<tr><td><a href ="../main/departement.php?d='.$dep['NumeroDep'].'">'.$dep['Département']."</a></td></tr>"; #liens vers les pages departements
 }
 echo "</table>";
  echo "<p>Les 10 meilleurs lycées de la région :</p>";

 $repL = $bdd->query(
 "SELECT * FROM lycees,departement,communes,region
WHERE lycees.code_commune=communes.Code_commune
AND communes.Code_departement=departement.NumeroDep
AND departement.Code_Région=region.Code_Region
AND region.Code_Region = '$codeR'
ORDER BY lycees.taux_brut_de_reussite_total_series DESC
LIMIT 10"); #selection 10 meilleurs lycées de la région

echo"<ul>";

 while($top10 = $repL->fetch()){
	 echo "<a href='../option/lycee.php?l=".$top10['code_etablissement']."'>".$top10['etablissement']."</a>
   <li>Taux de réussite : ".$top10['taux_brut_de_reussite_total_series']."</li></br>"; #liens vers les pages lycees
 }
 echo"</ul>";
?>

</p>


</div>

<footer id="footer">
<?php require '../elements/footer.php'; ?>
</footer>

</body>

</html>
