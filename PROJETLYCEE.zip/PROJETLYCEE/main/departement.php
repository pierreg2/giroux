<?php
session_start();
?>

<html>

<head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <link rel="stylesheet" href="../styles/styleformulaire.css" type="text/css" media="screen" />
          <title> Département </title>
          <h4> Département</h4>
</head>

<body>
  <div id="menuArea">
  <?php require '../elements/menu.php'; ?>
  </div>



<p class='Département'>
  <?php
         INCLUDE('bd.php');
         $bdd=getBD();
         $codeD = $_GET['d'];
         $repD = $bdd->query("select * from `departement` where NumeroDep='$codeD'"); //recupere infos du departement passé en GET
         $dep = $repD->fetch();
         $nomD = $dep['Département'];
         echo'<div id="container1">';
         echo "<h4>".$nomD." (".$codeD.")</h4>";


         echo "<center><p> Villes ayant un lycée dans le département :</p></center>";

          echo "<table class=tableauregion>";

         $repC = $bdd->query("select * from `communes` where Code_departement='$codeD'"); //affiche les villes du departement (il n'y a que des villes ayant un lycee dans la bd)
         while($communes = $repC->fetch()){
        	 echo '<tr><td><a href ="ville.php?v='.$communes['Code_commune'].'">'.$communes['Ville']."</a></tr></td>";
         }
          echo "</table>";
         echo "<p>Les 10 meilleurs lycées du département :</p>";

         $repL = $bdd->query(
         "select * from lycees,departement,communes
        where lycees.code_commune=communes.Code_commune
        and communes.Code_departement=departement.NumeroDep
        and departement.NumeroDep = '$codeD'
        order by  lycees.taux_brut_de_reussite_total_series desc
        limit 10"); //trie les lycees par taux de reussite et affiche les 10 premiers

        echo"<ul>";

         while($top10 = $repL->fetch()){
        	 echo "<a href='../option/lycee.php?l=".$top10['code_etablissement']."'>".$top10['etablissement']."</a><li> Taux de réussite : ".$top10['taux_brut_de_reussite_total_series']."</li></br>";
         }
         echo'</div>';
         echo"</ul>";

  ?>

</p>

<footer id="footer">
<?php require '../elements/footer.php'; ?>
</footer>

</body>

</html>
