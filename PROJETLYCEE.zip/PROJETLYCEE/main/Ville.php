<?php
session_start();
?>
<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <link rel="stylesheet" href="../styles/styleformulaire.css" type="text/css" media="screen" />
      <title> Ville </title>
      <h4> Ville </h4>
</head>


<body>

  <div id="menuArea">
  <?php require '../elements/menu.php'; ?>
  </div>

<p class='Ville'>
<?php
 INCLUDE('../main/bd.php');
 $bdd=getBD();
 $codeV = $_GET['v']; //on recupere le code de la ville en GET
 (isset ($_GET['tri'])) ? $tri=$_GET['tri'] : $tri = "taux_brut_de_reussite"; //si elle existe on recupere la variable de tri des lycee sinon on les tri par defaut par taux de reussite
 $repV = $bdd->query("SELECT * FROM `communes` WHERE Code_commune='$codeV'"); //on recupere les infos de la ville
 $ville = $repV->fetch();
 $nomV = $ville['Ville'];

 echo'<div id="container1">';
 echo "<h4>".$nomV."</h4>";
 ?>

 <form method='get' action='Ville.php' class="form-style-10"> <!--formulaire pour choisir le critere de tri-->
Trier par:

<select id="tri" name='tri'>
    <option value="taux_brut_de_reussite">Taux de réussite</option>
    <option value="effectif_present">Effectif</option>
    <option value="PU">Public</option>
    <option value="PR">Privé</option>
</select>
<?php echo "<input type='hidden' name='v' value='".$codeV."'>"?> <!--renvoie aussi le code de la ville quand on valide le choix-->
<input type='submit' value='OK'>
</form>

<?php

 if($tri == 'taux_brut_de_reussite' or $tri == 'effectif_present'){ //si le tri permet d'afficher tous les lycees
	 ($tri == 'taux_brut_de_reussite') ? $aff1='Taux de réussite' : $aff1 = 'Effectif'; //on definit le critere affiché en fonction du choix
	 $aff2 = $tri.'_total_series'; //on definit le critere qui sera cherché dans la bd en concatenant le choix et "total serie"

     $repNbL = $bdd->query(
	 "select count(*) as nb from lycees,communes
	where lycees.code_commune=communes.Code_commune
	and communes.Code_commune = '$codeV'"); //compte le nb de lycees de la commune

	 $rq = "select * from lycees,communes
	WHERE lycees.code_commune=communes.Code_commune
	AND communes.Code_commune = '$codeV'
	ORDER BY lycees.".$tri."_total_series DESC"; //selectionne les infos des lycees et les tri en fonction du critere choisi

	 $repL = $bdd->query($rq);

	 $nb = $repNbL->fetch();

	 echo "<p>Il y a ".$nb['nb']." lycées à ".$nomV." :</p>";
	 echo "<p id='pchoix'>";
   echo"<ul>";
	 while($lyc = $repL->fetch()){
		 echo "<a href='../option/lycee.php?l=".$lyc['code_etablissement']."'>".$lyc['etablissement']."</a> <li>".$aff1." : ".$lyc[$aff2]."</li></br>"; //affiche les lycees et l'info choisie par le critere
	 }
   echo"</ul>";
 }

 elseif($tri == 'PU' or $tri == 'PR'){ //si le critere ne selectionne que certains lycees
	 ($tri == 'PR') ? $type = 'privé' : $type = 'public';

	 $repNbL = $bdd->query(
	 "SELECT COUNT(*) AS nb FROM lycees,communes
	WHERE lycees.code_commune=communes.Code_commune
	AND lycees.public_ou_prive = '$tri'
	AND communes.Code_commune = '$codeV'");

	 $rq = "SELECT * FROM lycees,communes
	WHERE lycees.code_commune=communes.Code_commune
	AND lycees.public_ou_prive = '$tri'
	AND communes.Code_commune = '$codeV'
	ORDER BY lycees.taux_brut_de_reussite_total_series DESC";
	// echo $rq;

	 $repL = $bdd->query($rq);

	 $nb = $repNbL->fetch();
	 echo "<p>Il y a ".$nb['nb']." lycées ".$type."(s) à ".$nomV." :</p>";
	 echo "<p id='pchoix'>";

   echo"<ul>";
	 while($lyc = $repL->fetch()){ //affiche les lycees correspondants et leur taux de reussite
		 echo "<a href='../option/lycee.php?l=".$lyc['code_etablissement']."'>".$lyc['etablissement']."</a><li>Taux de réussite : ".$lyc['taux_brut_de_reussite_total_series']."</li></br>";
	 }
   echo"</ul>";
 }


  echo'</div>';

?>

</p>
<footer id="footer">
<?php require '../elements/footer.php'; ?>
</footer>

</body>

</html>
