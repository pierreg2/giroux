<?php
session_start();
?>

<html>
		<div class="page">
	<head class="site-header">
						<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
						<link rel="stylesheet" href="../styles/indexstye.css" type="text/css" media="screen" />

						<title> Un Lycée à votre image </title>

						<h1>
								UN LYCÉE À VOTRE IMAGE
									<img src="../images/LEF.jpg" alt="Liberté Egalité Fraternité" style="float:left;" width="20%">
									<img src="../images/edu.jpeg" alt="Diplôme" style="float:right;" width="19%">
						</h1>



				<center>
	 				<div class="form-style-10">
			 				<div class="inner-wrap">
			 					<form method="POST" action="../elements/search.php">
				 							Que recherchez-vous?
									<table>
										<td><input type="search" name="recherche" placeholder="Tapez votre recherche…" value="" /></td>
										<td><input type="submit" name="recherchebouton" value="Rechercher" /></td>
								  </table>
			 					</form>
	 						</div>
 	 					</div>
			 </center>



	</head>

  <body>



							<?php
							if(isset($_SESSION['utilisateur']) == FALSE){

								echo'<form action="../inscription/formulaire.php" method="get"  autocomplete="off">';

								echo'<div class="form-style-10">';
								echo'<center><input type="submit" value="Inscription"></center>';

								echo '</div>';
								echo '</form>';

								echo '<div class="connexion">';
								echo'<form  action="../sessions/connecter.php" method="get" autocomplete="off">';

								echo'<div class="form-style-10">';

								echo'<label for="name">Mail :</label></br>';
								echo'<input type="text" id="name" name="user_mail">';

								echo'<label for="password">Mot de passe :</label></br>';
								echo'<input type="password" id="password" name="user_password">';
								echo'<br>';
								echo'<center><input type="submit" value="Connexion"></br></br></center>';
								//echo'<button><action="inscription.php"></a>';

							echo'</div>';
							echo'</form>';
echo'</div>';
							}
							else{
								echo'<h5>';
								echo'Chèr(e) ';
								echo $_SESSION['utilisateur']['user_categorie'];
								echo', bienvenue sur notre site!';
								echo '</h5>';

							}


			if(isset($_SESSION['utilisateur']) == TRUE){
									echo'<form  action="../sessions/deconnexion.php" method="get"  autocomplete="off">';

									echo'<div class="form-style-10">';
									echo' <input type="submit"  value="Déconnexion">';
									echo'</div>';

									echo '</form>';
							}
			?>



					<div id="container3">

						<?php
								require 'bd.php';
								$bdd=getBD();
								echo '<MAP name="map1">';
								$reg=$bdd->query('select * from carte');
								while($region=$reg->fetch()){
										echo '<AREA id=hover ';
										echo 'HREF="region.php?r='.$region['ID'].'"';
										echo 'SHAPE="poly"';
										echo 'ALT="'.$region['title_alt'].'"';
										echo 'TITLE="'.$region['title_alt'].'"';
										echo 'COORDS="'.$region['coords'].'"';
										echo '/>';
										}
										echo '</MAP>';
								?>
									<img src="../images/MAP.png"  USEMAP="#map1">

					</div>

	<div id="mgauche">
						TOP 20 DES LYCÉES DE FRANCE
						<div id=divider></div>
		<?php
		 	$j=0;
			$bdd = new PDO('mysql:host=localhost;dbname=projet;charset=utf8', "root", "root");

			$req=  " select * from lycees where public_ou_prive='PU' order by taux_brut_de_reussite_total_series desc limit 20 ";
			$rep = $bdd->query($req);

			while($row=$rep->fetch()){

		    $j++;

			  echo '<ul>'.$j.'<li><a href="../option/lycee.php?l='.$row['code_etablissement'].'">'.$row['etablissement'].'</a> </li></ul>';;
		          }
		         ?>
					</div>

					<div id="mgauche1">
						<br>
						<a href="../contact/contact.php">CONTACTEZ NOUS</a>


					</div>

			<?php

				 if(isset($_SESSION['utilisateur']) == TRUE){
					 	echo'<div id="contribution">';
						echo'<div id=divider></div>';
						echo 'VOTRE AVIS NOUS INTERESSE !';
						echo'<div id=divider></div>';
						echo '<br>';
						echo'Une simple contribution peut nous aider à améliorer notre site';
						echo '<br>';
						echo '<br>';
						echo' <a href="../contribution/contribution.php">CONTRIBUER</a>';
						echo'<div id=divider></div>';
						echo'</div>';
						echo '<br>';
						echo '<br>';


					 	 $depUser = $_SESSION['utilisateur']['user_departement'];
					 	 $req = "select * FROM lycees, communes WHERE lycees.code_commune = communes.Code_commune AND communes.Code_departement = $depUser ORDER BY taux_brut_de_reussite_total_series LIMIT 5";
					 	 $rep=$bdd->query($req);

					 	   echo '<div class="right">';
							 echo 'Les meilleurs lycées de votre département';
					 		 echo '<ul>';

					 			 while ($lycee = $rep->fetch()){
					 			echo '<li><a href="../option/lycee.php?l='.$lycee['code_etablissement'].'">'.$lycee['etablissement'].'</a> </li></br>';
					 			 }
								 echo '</ul>';
								 echo '</div>';
							}
					?>




<footer id="footer">
<?php require '../elements/footer.php'; ?>
</footer>



</body>

</html>
