<!DOCTYPE html>
<html>
    <head>
    	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<title>Information</title>
	</head>

<body>

  <?php
       INCLUDE('../main/bd.php');
       $bdd=getBD();
       echo "avis" .$_GET['avis'];
       echo "positif_negatif" .$_GET['positif_negatif'];
       echo "code_lycee" .$_GET['code_lycee'];

		//insere dans la bd les informations du nouvel avis

       $req='insert into avis(avis, positif_negatif, code_lycee)
       values(
           "'.$_GET['avis'].'",
           "'.$_GET['positif_negatif'].'",
           "'.$_GET['code_lycee'].'"

         )';

         //echo $req; verification de la req

         $bdd->query($req);
         echo '<meta http-equiv="refresh" content="0; URL=../main/index.php"/>';

  ?>
