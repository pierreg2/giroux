
<?php
	include '../main/bd.php';
	$bdd = getBD();
	if(isset($_POST["idLycee"])){//si un lycee est envoye en post on le passe en lycee selectionné
		$lyceeSelected = $_POST["idLycee"];
	//on selectionne les infos du lycee
		$req = "SELECT * FROM lycees WHERE code_etablissement='".$lyceeSelected."'";
		  $rep=$bdd->query($req);

		while($lycee = $rep->fetch()){
			$codeCommune = $lycee['code_commune'];
			$type = $lycee['public_ou_prive'];
			$taux = $lycee['taux_brut_de_reussite_total_series'];
			$eff = $lycee['effectif_present_total_series'];
		}
	}?>
	<!--affiche les champs préremplis-->
	<?php echo'<label>Code postal <input type="text" name="CodePostal" value="'.$codeCommune.'" /></label>';?>
	<?php echo'<label>Type du lycée <input type="text" name="TypeLycee" value="'.$type.'" /></label>';?>
	<?php echo'<label>Effectif <input type="text" name="Effectif" value="'.$eff.'" /></label>';?>
	<?php echo'<label>Taux de réussite<input type="text" name="TauxReussite" value="'.$taux.'" /></label>';?>
