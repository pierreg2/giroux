<?php
session_start();
?>

<!DOCTYPE html>
<html>
   <head>
     <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
     <link rel="stylesheet" href="../styles/styleformulaire.css" type="text/css" />

        <title>CONTRIBUTION</title>
        <h4> Contribution </h4>
  </head>
<br>
<br>
<br>
<body onload="remplissage()"><!-- on appelle la fonction quand on charge la page -->



    <div id="menuArea">
	<?php require '../elements/menu.php';?>
    </div>

        <div id="container1">
          <p>
            Veuillez contribuer à notre site avec des informations qui pourrait nous aider à améliorer notre contenu !
          </p>

            <div class="form-style-10">
	          <h1>Informations<span>Informations sur le lycée</span></h1>
	             <form  method="get" action="information.php" autocomplete="off">
    	            <div class="inner-wrap">

                      <label>Nom du lycée</label>

                        <select name="code_lycee" id="code_lycee" onchange="remplissage()">  <!-- on appelle la fonction quand on selectionne un nouvel item -->
    		<option value='-1'>-- Choisir un lycée --</option>  <!-- 1er item de la liste -->

    			<?php
    				//on selectionne les infos des lycees et communes et on les classe par nom de ville
    				$req='select lycees.*, communes.* from lycees,communes where lycees.code_commune=communes.Code_commune ORDER BY communes.Ville';
    				INCLUDE('../main/bd.php');
    				$bdd=getBD();
    				$rep=$bdd->query($req);
    				if(isset($_GET['lycee'])){$cl = $_GET['lycee'];} //si il y a un get[lycee] on recupere le code lycee

    				while ($lycee = $rep->fetch()){
    					echo $lycee['code_etablissement'];
    					if ($lycee['code_etablissement'] == $cl){ //si on a recupere un code lycee on le passe en 'selected' dans la liste deroulante
    						echo "<OPTION value=".$lycee['code_etablissement']." selected='selected'>".$lycee['Ville'].'  ('.$lycee['Code_departement'].') -  '.$lycee['etablissement']."</OPTION>";
    					}
    					else{ //on affiche tous les lycees a la suite dans la liste
    						echo "<OPTION value=".$lycee['code_etablissement'].">".$lycee['Ville'].'  ('.$lycee['Code_departement'].') -  '.$lycee['etablissement']."</OPTION>";
    					}
    				}
    			?>
        </select>


						  <script type='text/javascript'> /* la méthode est inspirée de ce site : https://siddh.developpez.com/articles/ajax/ */

			function getXhr(){ //creation objet XmlHttpRequest
                var xhr = null;
				if(window.XMLHttpRequest) // pour firefox et autres moteurs de recherche
				   xhr = new XMLHttpRequest();
				else if(window.ActiveXObject){ // pour Internet Explorer
				   try {
			                xhr = new ActiveXObject("Msxml2.XMLHTTP");
			            }
				   catch (e) { //gestion des erreurs : si ne marche pas avec Msxml2, essaie avec Microsoft
			                xhr = new ActiveXObject("Microsoft.XMLHTTP");
			            }
				}
				else { // si XMLHttpRequest non supporté par le navigateur
				   alert("XMLHTTPRequest non supporté par le navigateur");
				   xhr = false;
				}
                return xhr;
			}


			// Fonction appelée à chaque fois que la page est rechargée ou un item de la liste sélectionné
			function remplissage(){
				var xhr = getXhr(); //On recupere l'objet XmlHttpRequest

				xhr.onreadystatechange = function(){ // Fonction executee quand la page est prete
					if(xhr.readyState == 4 && xhr.status == 200){ // On ne fait quelque chose que si on a tout reçu et que le serveur est pret
						leselect = xhr.responseText;
            console.log(leselect); // On recupere la reponse
						document.getElementById('remplissageAuto').innerHTML = leselect; // On ecrit dans le html avec innerHTML

					}
				}

				xhr.open("POST","ajaxContribution.php",true);
				xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded'); //Assigne une valeur au header HTTP qui sera envoyé lors de la requête
				sel = document.getElementById('code_lycee');
				idLycee = sel.options[sel.selectedIndex].value; //On recupere l'id du lycee selectionne
				if(idLycee != -1){
					xhr.send("idLycee="+idLycee); //Si l'item sélectionné n'est pas le 1er ('Choisir un lycee') on envoie l'id du lycee
				}
			}
			</script>


        	            <div id="remplissageAuto">

						<label>Code postal <input type="text" name="CodePostal" value="" /></label>
						<label>Type du lycée <input type="text" name="TypeLycee" value="" /></label>
						<label>Effectif <input type="text" name="Effectif" value="" /></label>
						<label>Taux de réussite<input type="text" name="TauxReussite" value="" /></label>

						</div>

                      <div class="button-section">
                          <label>  Avis sur le lycée <br><br>
                                 <input type="radio"  name="positif_negatif" value="1">Positif</label>
                          <label><input type="radio"  name="positif_negatif" value="0">Négatif</label>
                      </div>

                      <label>Avis<textarea type="text" name="avis" value="<?php if(isset($_GET['avis'])){echo $_GET['avis'];} ?>"/></textarea></label>


   		             </div>
                   <div class="button-section">
                    <input type="submit" name="Envoyer"/>
                  </div>
	              </form>
	        </div>
	   </div>


     <footer id="footer">
     <?php require '../elements/footer.php'; ?>
     </footer>

</body>
</html>
