
<!DOCTYPE html>
<html>
<html>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" href="../main/indexstye.css" type="text/css" media="screen" />
<title>Connexion</title>
</head>

<body>
	<h1> <a id="link" href="../main/index.php"> Projet </a></h1>

	<a href="inscription.php" class="active"> Inscription </a>
	<form method="get" action="connecter.php" autocomplete="off">
	<p>Adresse email <INPUT type="text" name="user_mail" value="<?php if(isset($_GET['user_mail'])){echo $_GET['user_mail'];} ?>"></p>
	<p>Mot de passe <INPUT type="password" name="user_password" value=""></p>
<p>
<input type="submit" value="Envoyer">
</p>
	</form>


</body>
</html>
