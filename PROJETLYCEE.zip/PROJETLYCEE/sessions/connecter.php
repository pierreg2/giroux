<?php
session_start();
?>
<html>
<head>
<title>Connexion</title>

<?php

$utilisateur = new PDO('mysql:host=localhost;dbname=projet;charset=utf8','root', 'root');
$user_mail = $_GET['user_mail'];
$user_password = $_GET['user_password'];

if($_GET['user_password']!="" && $_GET['user_mail']!="") {
	$rep = $utilisateur->query("select * from utilisateur where mail='$user_mail' and mdp='$user_password'");
	$info = $rep->fetch();
	if($_GET['user_password']==$info["mdp"] && $_GET['user_mail']==$info["mail"]) {
		$_SESSION['utilisateur']=array('user_mail'=>$info['mail'],'user_password'=>$info['mdp'],'user_categorie'=>$info['statut'],'user_codepostal'=>$info['codepostal'],'user_departement'=>$info['departement']);
		echo "<meta http-equiv='refresh'; content='0;URL=../main/index.php'>";
		}
		else{
	echo "Informations erronées";
	echo "<meta http-equiv='refresh' content='0;URL=../main/index.php?user_mail=".$_GET['user_mail']."'>";
}
}
else{
	echo "Informations erronées";
	echo "<meta http-equiv='refresh' content='0;URL=../main/index.php?user_mail=".$_GET['user_mail']."'>";
}

?>


</head>
<body>
</body>
</html>
