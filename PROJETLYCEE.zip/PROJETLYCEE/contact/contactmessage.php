<?php
            if(isset($_POST['envoyer'])) {
              $statut = $_POST['statut'];
              $nom = $_POST['nom'];
              $prenom = $_POST['prenom'];
              $objet = $_POST['objet'];
              $emailfrom = $_POST['email'];
              $message = $_POST['message'];

              }
              if($_POST['statut']=="" || $_POST['nom']=="" || $_POST['prenom']=="" || $_POST['email']!= $_POST['objet']=""|| $_POST['message']!= $_POST['message']="")
              {
               echo '<meta http-equiv="refresh" content="0; URL=contact.php?statut='.$_POST['statut'].'&nom='.$_POST['nom'].'&prenom='.$_POST['prenom'].'&email='.$_POST['email'].'&message='.$_POST['message'].'" />';
              }

              else
              {

              $mailto = "salmasamir1996@gmail.com";
              $headers = "De: ".$emailfrom;
              $txt = " Vous avez reçu un e-mail de ".$nom." ".$prenom." ayant le statut de ".$statut.".\n\n".$message;

              mail($mailto, $objet, $txt, $headers);
              header( "Location: contact.php?mailsend");
            }
?>
