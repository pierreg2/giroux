<!DOCTYPE html>
<html>
   <head>
     <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
     <link rel="stylesheet" href="../styles/styleformulaire.css" type="text/css" />

            <title>CONTACT</title>

    </head>

    <body>

      <div id="container6">
        <div class='container'>
            <div class='content'>
                <center><h5>Nous nous tenons à votre disposition</h5></center>
              <form class='input-fields'  action="contactmessage.php" method="POST">
                <input type='text' name='statut'placeholder='Statut' class='input-line full-width'></input>
                <input type='text' name='nom' placeholder='Nom' class='input-line full-width'></input>
                <input type='text' name='prenom'placeholder='Prénom' class='input-line full-width'></input>
                <input type='text' name='objet' placeholder='Objet' class='input-line full-width'></input>
                <input type='email' name='email' placeholder='E-mail' class='input-line full-width'></input>
                <textarea rows="9" cols="10" name="message" class='input-line full-width'></textarea>
              <div><button type="submit" name='envoyer' class='ghost-round full-width'>Envoyer mon message !</button></div>
              </form>
            </div>
        </div>
      </div>


    <div id="container4">
          <center><h4>CONTACTEZ</h4>
            <h4>NOUS !</h4></center>
          <h5>Adresse </h5>
          <img id="imagecontact" src="../images/paulva.png" >
          <ul><li>Université Paul-Valéry Montpellier 3<br>
                  Route de Mende 34199 Montpellier Cedex 5<br>
                  UFR6- Bâtiment Joë Bousquet (Bât. B 1er étage)
          </li></ul>
          <h5> Numéro de téléphone </h5>
          <ul><li> 00 33 4 67 14 20 00 </li></ul>
          <h5> E-Mail </h5>
          <ul><li> projet_lycee@gmail.com </li></ul>
                <br>
      </div>






      <footer id="footer">
      <?php require '../elements/footer.php'; ?>
      </footer>


  </body>
</html>
