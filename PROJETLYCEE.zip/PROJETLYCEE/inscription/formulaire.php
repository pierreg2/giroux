<?php
session_start();
?>


<!DOCTYPE html>
<html>
   <head>
     <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
     <link rel="stylesheet" href="../styles/styleformulaire.css" type="text/css" />

        <title>FORMULAIRE</title>
        <h4> Formulaire d'inscription</h4>

    </head>
      <br>
      <br>
      <br>
      <br>
      <br>
      <br>
    <body>

        <div id="menuArea">
        <?php require '../elements/menu.php'; ?>
        </div>

	     <div id="container1">
         <p> Veuillez vous inscrire afin de pouvoir contribuer au site ! </p>

         <div class="form-style-10">
           <h1>FORMULAIRE<span>Veuillez vous inscrire afin de pouvoir contribuer au site !</span></h1>
            <form  method="get" action="inscription.php" autocomplete="off" >
                <div class="section"><span>1</span>Localisation</div>
                  <div class="inner-wrap">

                      <label>Département* </label>
                      <select name="dep">
                            <?php
                              //Requette pour trouver la liste des régions
                            $req='select distinct NumeroDep, Département FROM Departement ORDER BY Département';
                            echo $req;
                            INCLUDE('../main/bd.php');
                            $bdd=getBD();
                            $rep=$bdd->query($req);
                            while ($dep = $rep->fetch())
                            echo "<OPTION value=".$dep['NumeroDep'].">".$dep['Département']. "</OPTION>";
                            ?>
                        </select>
                      <label>Code postal<input type="text" name="codep" value="<?php if(isset($_GET['codep'])){echo $_GET['codep'];} ?>"/></label>
                  </div>

                <div class="section"><span>2</span>Statut</div>
                  <div class="inner-wrap">
                    <div class="button-section">
                        <label> <input  type="radio" name="statut" value="parent">Parent</label>
                        <label> <input  type="radio"  name="statut" value="élève">Elève</label>
                        <label> <input  type="radio"  name="statut" value="prof">Professeur</label>
                    </div>
                  </div>

                <div class="section"><span>3</span>Coordonnées</div>
                  <div class="inner-wrap">
                        <label> Addresse mail*<input type="email" name="mail" value="<?php if(isset($_GET['mail'])){echo $_GET['mail'];} ?>"/></label>
                        <label> Confirmation* <input type="text" name="mail" /></label>
                </div>

                <div class="section"><span>4</span>Mots de passe</div>
                  <div class="inner-wrap">
                        <label>Mots de passe<input type="password" name="mdp" value="<?php if(isset($_GET['mdp'])){echo $_GET['mdp'];} ?>"/></label>
                        <label>Confirmation <input type="password" name="mdp1" /></label>
                  </div>

                <div class="button-section">
                        <input id="monBouton" type="submit" name="Sign Up" />

                      <span class="privacy-policy">
                        <input type="checkbox" name="cond">J'accepte les termes de confidentialité et d'utilisation.
                      </span>
                </div>
           </form>
         </div>

       </div>

       <footer id="footer">
       <?php require '../elements/footer.php'; ?>
       </footer>

</body>
</html>
