<?php
session_start();
?>

<html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <link rel="stylesheet" href="../styles/styleformulaire.css" type="text/css" media="screen" />
      <title> Lycée </title>
      <h4> Lycée</h4>
</head>

<body>
  <div id="menuArea">
  <?php require '../elements/menu.php'; ?>
  </div>

<p class='Lycée'>

<?php
 INCLUDE('../main/bd.php');
 $bdd=getBD();
 $codeL = $_GET['l']; //on recupere le code lycee en GET
 $repL = $bdd->query("select * from lycees where code_etablissement='$codeL'"); //on selectionne ses infos
 $lycee = $repL->fetch();
 $nomL = $lycee['etablissement'];
 $codeC = $lycee['code_commune'];
 $academie = $lycee['academie'];
 $pupv = $lycee['public_ou_prive'];
 $statut = 'Non précisé'; //on attribuera public pour PU, prive pour PR et valeur par defaut si pas renseigné dans la bd
 if($pupv == 'PU'){
	$statut = 'Public';}
 if($pupv == 'PR'){
	 $statut = 'Privé';}
 $eff = $lycee['effectif_present_total_series'];
 $taux = $lycee['taux_brut_de_reussite_total_series'];

 $repC = $bdd->query("select * from communes where Code_commune='$codeC'"); //recupere la ville du lycee
 $commune = $repC->fetch();
 $nomC = $commune['Ville'];
 $numD = $commune['Code_departement'];

 $repD = $bdd->query("select * from departement where NumeroDep='$numD'"); //recupere departement
 $departement = $repD->fetch();
 $nomD = $departement['Département'];

 $reqOptions = "SELECT DISTINCT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = N'options' AND COLUMN_NAME != 'code_etablissement'";
 $repO=$bdd->query($reqOptions);



echo'<div id="container1">';

 //affiche toutes les infos sous forme de tableau
 echo "<h4>".$nomL."</h4>";
 echo "<table style='margin: auto;'>";
 echo "<tr><td>Ville</td><td>".$nomC."</td></tr>";
 echo "<tr><td>Département</td><td>".$nomD."</td></tr>";
 echo "<tr><td>Académie</td><td>".$academie."</td></tr>";
 echo "<tr><td>Statut</td><td>".$statut."</td></tr>";
 echo "<tr><td>Effectif</td><td>".$eff."</td></tr>";
 echo "<tr><td>Taux de réussite (%)   </td><td>".$taux."</td></tr>";
 echo "</table>";

 echo "<p>Options présentes dans ce lycée :</p></br>";

 echo '<table>';
 $i = 1;
 while($option = $repO->fetch()){
	$nomOption=$option[0];
	$reqOptions2="SELECT ".$nomOption." FROM options WHERE code_etablissement = '".$codeL."'";
	$repO2 = $bdd->query($reqOptions2);
	$option2 = $repO2->fetch();
	if($option2[0]==1){
    echo"<ul>";
		echo '<td><p><li>'.$nomOption.'</li></p></td>' ;
		if($i%3==0){ //on fait des rangees de 2 options
			echo "<tr></tr>";

      echo"</ul>";
		}
		$i=$i+1;
	}
 }
	echo "</table>";


if(isset($_SESSION['utilisateur']) == TRUE){ //si utilisateur connecté affiche bouton vers page options
	echo'<form id="form" action="option2.php" method="get" style="margin: auto" autocomplete="off">';
	echo'<div class="form-style-10">';
	echo'<input type="hidden" id="lycee" name="lycee" value="'.$codeL.'" >';
	echo'<center><input type="submit" value="Modifier les options"></center>';
	echo'</div>';
	echo'</form>';
}


 $repA = $bdd->query("select * from avis where code_lycee='$codeL'"); //recupere les avis sur ce lycee
 $noteL = 0; //cumulera les avis positifs (1) et negatifs (0)
 $nbAvis = 0; //nb d'avis sur ce lycee
 while($avis = $repA->fetch()){
	 $texteAvis = $avis['avis'];

   echo "<table class=tableauregion>";
	 echo "<tr><td>$texteAvis</td></tr></br>";
   echo "</table>";
	 $noteL += $avis['positif_negatif'];
	 $nbAvis++;
 }
 if($nbAvis != 0){ //si il y a au moins un avis on fait la moyenne des positifs/negatifs pour l'afficher en pourcentage de positifs
	 $noteMoy = ($noteL/$nbAvis)*100;
	 echo "<center><p>Pourcentage de commentaires positifs : ".round($noteMoy, 1)."%";
 }

 if(isset($_SESSION['utilisateur']) == TRUE){//si utilisateur connecté affiche bouton vers page avis
	echo'<form id="form" action="../contribution/contribution.php" method="get" style="margin: auto" autocomplete="off">';
	echo'<div class="form-style-10">';
	echo'<input type="hidden" id="lycee" name="lycee" value="'.$codeL.'" >';
	echo'<center><input type="submit" value="Donner un avis !"></center>';
	echo'</div>';
	echo'</form>';
}

 ?>



</div>
</p>


<footer id="footer">
<?php require '../elements/footer.php'; ?>
</footer>


</body>

</html>
