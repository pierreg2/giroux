<html>
<head>
<title>Ajouter</title>


<?php

include '../main/bd.php';
$bdd = getBD();

$req2 = "SELECT DISTINCT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = N'options' AND COLUMN_NAME != 'code_etablissement'";
$rep2=$bdd->query($req2);
$i = 0;
while ($option = $rep2->fetch()){
	//print_r($option);
	//print_r ($t[0]);
	$t=$option[0];
	#echo "t=".$t."</br>";
	if(isset($_GET[$t])){
		$optionCourante = $t;
		#echo "oc=".$optionCourante;
	$req="UPDATE options
		SET ".$optionCourante." = 1
		WHERE code_etablissement = '".$_GET['lycee']."'";
     $bdd->query($req);
	}
	#echo '<td><input type="checkbox" id="'.$option['COLUMN_NAME'].'" name="'.$option['COLUMN_NAME'].'" value="1"> '.$option['COLUMN_NAME'].'</td>' ;

}
#echo $req;

echo "<meta http-equiv='refresh'; content='0;URL=../option/option2.php?lycee=".$_GET['lycee']."'>";

?>


</head>
<body>
</body>
</html>
