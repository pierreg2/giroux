 <div id="gauche">
  <span> Supprimer</span>
   <br>
   <br>
    Les options suivantes sont présentes dans ce lycée, sélectionnez celles que vous souhaitez supprimer :
<form  method="get" action="suppressionoption.php" autocomplete="off" >
<?php
if(isset($_POST["idLycee"])){ //si un lycee est envoye en post on le passe en lycee selectionné
	$lyceeSelected = $_POST["idLycee"];
	include '../main/bd.php';
	$bdd = getBD();
	//on selectionne les noms de colonnes de la table option (liste des noms d'options)
	$req = "SELECT DISTINCT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = N'options' AND COLUMN_NAME != 'code_etablissement'";
	  $rep=$bdd->query($req);
	  echo '<table  id="optionCheckbox">';
	  $i = 1;
	while($option = $rep->fetch()){
		$nomOption=$option[0];
		$req2="SELECT ".$nomOption." FROM options WHERE code_etablissement = '".$lyceeSelected."'";
		 $rep2 = $bdd->query($req2);
		$option2 = $rep2->fetch();
		if($option2[0]==1){
			echo '<td><input type="checkbox" id="'.$nomOption.'" name="'.$nomOption.'" value="0"> '.$nomOption.'</td>' ;
			if($i%2==0){ //on fait des rangees de 2 options
				echo "<tr></tr>";
			}
			$i=$i+1;
		}
	}
	echo "</table>";
}
echo '<input type="hidden" name="lycee" value="'.$lyceeSelected.' "/>';
?>
	<div class="button-section">
		<input type="submit" name="Confirmer"/>
	</div>
	</form>
</div>
