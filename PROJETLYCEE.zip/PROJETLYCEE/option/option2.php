<?php
session_start();
?>

<!DOCTYPE html>
<html>
   <head>
     <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
     <link rel="stylesheet" href="../styles/styleformulaire.css" type="text/css" />

        <title>OPTIONS</title>
        <h4> OPTIONS </h4>

    </head>
    <body onload="ajoutOptions(), suppOptions()"> <!-- on appelle la fonction quand la page se charge -->

        <div id="menuArea">
        <?php require '../elements/menu.php'; ?>
        </div>
<div class="form-style-10">
    <h1> Sélectionnez votre lycée<span>classé par nom de ville </span></h1>


<div class="inner-wrap">
    <form>
    	<select name="lycee" id="lycee" onchange="ajoutOptions(), suppOptions()">  <!-- on appelle la fonction quand on selectionne un nouvel item -->
    		<option value='-1'>-- Choisir un lycée --</option>  <!-- 1er item de la liste -->

    			<?php
    				//on selectionne les infos des lycees et communes et on les classe par nom de ville
    				$req='select lycees.*, communes.* from lycees,communes where lycees.code_commune=communes.Code_commune ORDER BY communes.Ville';
    				INCLUDE('../main/bd.php');
    				$bdd=getBD();
    				$rep=$bdd->query($req);
    				if(isset($_GET['lycee'])){$cl = $_GET['lycee'];} //si il y a un get[lycee] on recupere le code lycee

    				while ($lycee = $rep->fetch()){
    					echo $lycee['code_etablissement'];
    					if ($lycee['code_etablissement'] == $cl){ //si on a recupere un code lycee on le passe en 'selected' dans la liste deroulante
    						echo "<OPTION value=".$lycee['code_etablissement']." selected='selected'>".$lycee['Ville'].'  ('.$lycee['Code_departement'].') -  '.$lycee['etablissement']."</OPTION>";
    					}
    					else{ //on affiche tous les lycees a la suite dans la liste
    						echo "<OPTION value=".$lycee['code_etablissement'].">".$lycee['Ville'].'  ('.$lycee['Code_departement'].') -  '.$lycee['etablissement']."</OPTION>";
    					}
    				}
    			?>
        </select>
    </form>
  </div>
      </div>
<br>
<br>


<div class="form-style-10">
  <div class="inner-wrap">

<div id="supp" class="section" >

  <span> Supprimer</span>
   <br>
   <br>
    Les options suivantes sont présentes dans ce lycée, sélectionnez celles que vous souhaitez supprimer :
</div>

</div>
</div>




<div class="form-style-10">
  <div class="inner-wrap">

<div id="ajout" class="section">
  <span> Ajouter</span>
   <br>
   <br>
    Les options suivantes sont absentes dans ce lycée,  sélectionnez celles que vous souhaitez ajouter :
</div>
    </div>

    </div>
  </div>

		<script type='text/javascript'> /* la méthode est inspirée de ce site : https://siddh.developpez.com/articles/ajax/ */

			function getXhr(){ //creation objet XmlHttpRequest
                var xhr = null;
				if(window.XMLHttpRequest) // pour firefox et autres moteurs de recherche
				   xhr = new XMLHttpRequest();
				else if(window.ActiveXObject){ // pour Internet Explorer
				   try {
			                xhr = new ActiveXObject("Msxml2.XMLHTTP");
			            }
				   catch (e) { //gestion des erreurs : si ne marche pas avec Msxml2, essaie avec Microsoft
			                xhr = new ActiveXObject("Microsoft.XMLHTTP");
			            }
				}
				else { // si XMLHttpRequest non supporté par le navigateur
				   alert("XMLHTTPRequest non supporté par le navigateur");
				   xhr = false;
				}
                return xhr;
			}


			// Fonction appelée à chaque fois que la page est rechargée ou un item de la liste sélectionné
			function ajoutOptions(){
				var xhr = getXhr(); //On recupere l'objet XmlHttpRequest

				xhr.onreadystatechange = function(){ // Fonction executee quand la page est prete
					if(xhr.readyState == 4 && xhr.status == 200){ // On ne fait quelque chose que si on a tout reçu et que le serveur est pret
						leselect = xhr.responseText;
            console.log(leselect); // On recupere la reponse
						document.getElementById('ajout').innerHTML = leselect; // On ecrit dans le html avec innerHTML

					}
				}

				xhr.open("POST","ajaxAjout.php",true);
				xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded'); //Assigne une valeur au header HTTP qui sera envoyé lors de la requête
				sel = document.getElementById('lycee');
				idLycee = sel.options[sel.selectedIndex].value; //On recupere l'id du lycee selectionne
				if(idLycee != -1){
					xhr.send("idLycee="+idLycee); //Si l'item sélectionné n'est pas le 1er ('Choisir un lycee') on envoie l'id du lycee
				}


			}

			function suppOptions(){
				var xhr = getXhr(); //On recupere l'objet XmlHttpRequest

				xhr.onreadystatechange = function(){ // Fonction executee quand la page est prete
					if(xhr.readyState == 4 && xhr.status == 200){ // On ne fait quelque chose que si on a tout reçu et que le serveur est pret
						leselect = xhr.responseText;
            console.log(leselect); // On recupere la reponse
						document.getElementById('supp').innerHTML = leselect; // On ecrit dans le html avec innerHTML

					}
				}

				xhr.open("POST","ajaxSupp.php",true);
				xhr.setRequestHeader('Content-Type','application/x-www-form-urlencoded'); //Assigne une valeur au header HTTP qui sera envoyé lors de la requête
				sel = document.getElementById('lycee');
				idLycee = sel.options[sel.selectedIndex].value; //On recupere l'id du lycee selectionne
				if(idLycee != -1){
					xhr.send("idLycee="+idLycee); //Si l'item sélectionné n'est pas le 1er ('Choisir un lycee') on envoie l'id du lycee
				}


			}
		</script>

    <footer id="footer">
    <?php require '../elements/footer.php'; ?>
    </footer>

</body>
</html>
